import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

/**
 * Created by stuxnet-il on 17/11/15.
 */
public class hangman extends JFrame {

    public static void main(String[] args)
    {
        System.out.println("Hello");
        JFrame MainFrame = new JFrame("HangMan");
        MainFrame.setSize(500, 1000);
        MainFrame.setLayout(new GridLayout());
        JCanvas canvas = new JCanvas();
        canvas.setSize(500,500);
        MainFrame.add(canvas);
        canvas.setVisible(true);
        MainFrame.setVisible(true);
        MainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        int x = canvas.getWidth()/2;
        int y = canvas.getHeight()/2;
        System.out.println(" x = " +x + ",y = " +y);
        Point p = new Point(x+100,y+100);
        Point center = new Point(x+500,y);
        hangman man = new hangman(p,center);
        hangman leg = new hangman(new Point(x+100,y+50),man.p);

        man.push(leg);
        man.radius = 100;
        BufferedImage img1=canvas.loadImage("logo.jpg");
        int i=0;
            while (true){
                canvas.startBuffer();
                canvas.clear();
                i++;
                canvas.drawImage(img1 , 0,0);
                canvas.drawString("TechAlien.in", 0 ,0);

                canvas.drawLine(center.x,center.y, man.p.x , man.p.y);
                //man.radar(canvas,center.x,center.y,100,5,300);
                //leg.radar(canvas,leg.p.x,leg.p.y,100,2,50);

                canvas.drawLine(man.p.x, man.p.y,leg.p.x,leg.p.y);
                System.out.println("MAN");
                man.fillcircle(center,canvas);
                System.out.println("LEG--------------------------------------------------");
                leg.fillcircle(man.p,canvas);
                canvas.setColor(Color.BLUE);
                man.REPAINT(canvas);
                leg.REPAINT(canvas);
                man.update_position(Math.toRadians(1));
                canvas.endBuffer();
                canvas.sleep(25);
            }


    }



    public void radar(JCanvas canvas , int x , int y , int number , int width , int maxradius){
        int radius=0;
        for (int i =0 ; i< number ; i++){
            canvas.setColor(Color.getHSBColor(2*i,2*i*i,2*i*i*i));
            radius = radius + width;
            if (radius>maxradius)
                break;
            canvas.drawOval(x-radius/2,y-radius/2 , radius,radius);
        }
    }








    public Point p;
    public Point center;
    public double angle;
    public double radius; //Point Center to Point p
    public int size_of_object = 20;
    public hangman[] list_of_entities = new hangman[20];
    public int number_of_entities=0;



    public hangman(Point p , Point center){
        this.p = p;
        this.angle = Math.atan( (center.getY()-p.getY()) / (center.getX()-p.getX()) );
        this.angle = Math.toRadians(this.angle);
        this.center = center;
        this.radius = distance(this.center, this.p);


    }

//    public double update_angle(double angle){
//        if (this.angle >  )
//    }

    public void REPAINT(JCanvas canvas){
        fillcircle(this.p ,canvas);
        canvas.setColor(Color.BLACK);
        int i, size = this.number_of_entities;
        for (i =0 ; i<size ; i++)
            this.list_of_entities[i].REPAINT(canvas);

    }


    public void fillcircle(Point p ,JCanvas canvas){
        canvas.fillOval( (int)p.getX()-this.size_of_object/2, (int)p.getY()-this.size_of_object/2 ,this.size_of_object , this.size_of_object);
    }

    public void update_position( double del_angle){

        this.angle = this.angle + del_angle;

        System.out.println("Angle=" + Math.toDegrees(this.angle));
        System.out.println("Radius=" + this.radius);
        this.p.x = this.center.x + (int)(this.radius*Math.sin(this.angle));
        this.p.y = this.center.y + (int)(this.radius*Math.cos(this.angle));
        System.out.println("Point=" + this.p);

        int i = 0 , size = this.number_of_entities;
        for(i = 0 ; i < size ; i++){
            //System.out.println("Not Build");
            this.list_of_entities[i].update_position(del_angle);
        }
    }

    public double distance(hangman a , hangman b){
        int x1 = a.p.x;
        int y1 = a.p.y;
        int x2 = b.p.x;
        int y2 = b.p.y;

        return Math.pow( (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2) , .5 );
    }

    public double distance(Point a , Point b){
        int x1 = a.x;
        int y1 = a.y;
        int x2 = b.x;
        int y2 = b.y;

        return Math.pow( (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2) , .5 );
    }

    public void push(hangman n){
        this.list_of_entities[this.number_of_entities] = n;
        this.number_of_entities ++;
    }



}
